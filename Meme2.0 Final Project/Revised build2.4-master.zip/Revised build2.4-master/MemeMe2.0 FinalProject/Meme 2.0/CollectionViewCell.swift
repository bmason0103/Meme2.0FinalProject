//
//  CollectionViewCell.swift
//  Exper
//
//  Created by Brittany Mason on 9/20/19.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeCollectionViewImage: UIImageView!
    
    @IBOutlet weak var memeLabel: UILabel!
    
    }
   

